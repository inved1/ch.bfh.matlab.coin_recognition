%settings file for coins and co


function mySettings = coin_recognition_settings()
        mySettings= csvread('settings.csv');       
end 