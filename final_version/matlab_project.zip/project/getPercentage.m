function retval = getPercentage(MassReference, MassCoin)
    retval = 100 / MassReference * MassCoin / 100;
end